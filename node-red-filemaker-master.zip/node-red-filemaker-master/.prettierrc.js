module.exports = {
  tabWidth: 2,
  useTabs: false
};
